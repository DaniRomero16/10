$(() => {

    $('ul').sortable();
    $('ul').disableSelection();

    $('#anadir').on('click', function () {
        let tarea = $('#inputTarea').val();
        let ObjLi = $('<li></li>');
        ObjLi.text(tarea);
        ObjLi.addClass('list-group-item');
        $('#pendientes').append(ObjLi);
    });

    $('#pendientes').on('click', 'li', function(){
        let ObjLi = $('<li></li>');
        ObjLi.text($(this).text());
        ObjLi.addClass('list-group-item');
        $('#probar').append(ObjLi);
        $(this).remove();
    });

    $('#probar').on('click', 'li', function(){
        let ObjLi = $('<li></li>');
        ObjLi.text($(this).text());
        ObjLi.addClass('list-group-item');
        $('#realizadas').append(ObjLi);
        $(this).remove();
    });

    $('#realizadas').on('click', 'li', function(){
        let ObjLi = $('<li></li>');
        ObjLi.text($(this).text());
        ObjLi.addClass('list-group-item');
        $('#pendientes').append(ObjLi);
        $(this).remove();
    });

    


});
